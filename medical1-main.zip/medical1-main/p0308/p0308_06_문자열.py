# 인덱싱[0],슬라이싱[0:4][:3][1:],len,upper,lower,swapcase,title

# shape_list = ["spadE","diamonD","heart","clover"]
# for i in shape_list:
#     # print(i.upper())
#     # print(i.title())
#     # print(i.swapcase())
#     print(i.lower())


# title = input("문자를 입력하세요>> ")
# # 역순출력 요세하녕안
# for i in range(len(title)): # 5
#     print(title[(len(title)-1)-i],end="")
    
    


# a = [1234,11111,1,145,20,1323456547]
# # 리스트의 각 숫자의 길이를 출력하시오.
# # 짝수만 문자길이를 출력하시오.
# for i in a:
#     if i%2==0:
#         print("숫자 : {}, 길이 : {} ".format(i,len(str(i))))
        
# # 한글자씩 출력을 해보세요.
# title = "혼자공부하는파이썬수업" 
# for i in range(len(title)):
#     print(title[i])
    
# print(title[0])    
# print(title[1])    
# print(title[2])    
# print(title[3])    
# print(title[4])    




# a = input("문자를 입력하세요.")
# print("현재 입력한 문자 길이 : ",len(a))



# a = 1000000
# b = "안녕하세요.반갑습니다.저는홍길동입니다"
# print(len(str(a)))
# print(len(b)) #문자열 길이 
# print(b[0])
# print(b[2])
# print(b[2:5])



# a="안녕"
# b=100000
# c=2000
# d="1000000"
# print(b+c)
# print(b+int(d)) #타입이 같아야 사칙연산이 가능

