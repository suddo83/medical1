ss = "123"
print("0123456789")
print(ss.center(10)) #빈 가운데 정렬
print(ss.center(10,"*")) #가운데 정렬
print(ss.rjust(10))  #우측정렬
print(ss.ljust(10))  #좌측정렬
print(ss.zfill(10))  #0으로 채워줌