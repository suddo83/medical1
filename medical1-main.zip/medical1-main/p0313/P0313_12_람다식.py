# 람다식함수
# def sum(num1,num2):
#     return num1+num2

# print(sum(10,20))


# def sum(num1,num2):
#     return num1+num2
a = lambda num1,num2:num1+num2
print(a(10,20))