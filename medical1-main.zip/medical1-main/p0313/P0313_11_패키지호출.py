# 같은 폴더내에서 찾음. 패키지명.모듈명 import 함수명 으로 선언해야 함.
from p0312.stuUpdate import *

stu_print()