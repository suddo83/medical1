# 리스트 대괄호, 출력 idx번호를 사용해서 출력
products = ["새우깡",90,1200]
print(products[0])

# 딕셔너리 중괄호, 출력 key를 사용해서 출력
students = {"stuNo":1,"name":"홍길동","kor":100,"eng":100,"math":100,"scie":99}
print(students["stuNo"])


students["총합"] = 399
print(students)

