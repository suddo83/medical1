from konlpy.tag import Okt

okt = Okt()
news1_lists = okt.nouns("바나나를 맛있게 먹었다")
