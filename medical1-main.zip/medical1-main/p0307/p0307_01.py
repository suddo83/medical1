stu_name = "홍길동" #타입 str
stuNo = 1 #타입 숫자 int

print(type(stuNo))
print(type(stu_name))