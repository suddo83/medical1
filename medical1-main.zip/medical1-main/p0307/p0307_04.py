stuInfo = {
    "stuNo":1,
    "id":"aaa",
    "pass":"1111",
    "name":"홍길동",
    "nicName":"길동스"
}

print(stuInfo.get("tel"))