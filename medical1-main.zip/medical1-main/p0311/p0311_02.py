# csv파일
student = "1,'홍길동',100,99,87,286,95.33,2"
s_list = student.split(",") #문자열 분리함수
print(s_list[0])



            