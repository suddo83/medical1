# 함수선언
def plus(v1,v2):
    result = 0
    result = v1+v2
    return result


#함수호출
print(plus(100,200))
# hap = plus(100,200)
# print(hap)
print("프로그램종료")
    
    
    