# 문자열로 출력해보기
print('{}*{}={}'.format(2,1,2*1))
print('{}*{}={}'.format(2,2,2*2))
print('{}*{}={}'.format(2,3,2*3))

# 변수를 만들어서 출력
num = 3
print('{}*{}={}'.format(num,1,num*1))
print('{}*{}={}'.format(num,2,num*2))
print('{}*{}={}'.format(num,3,num*3))

# 입력을 받아서 출력
num = int(input("원하는 단을 입력하세요:  "))
print('{}*{}={}'.format(num,1,num*1))
print('{}*{}={}'.format(num,2,num*2))
print('{}*{}={}'.format(num,3,num*3))
print('{}*{}={}'.format(num,4,num*4))
print('{}*{}={}'.format(num,5,num*5))
print('{}*{}={}'.format(num,6,num*6))
print('{}*{}={}'.format(num,7,num*7))
print('{}*{}={}'.format(num,8,num*8))
print('{}*{}={}'.format(num,9,num*9))