import operator
from konlpy.tag import Okt

okt = Okt()
